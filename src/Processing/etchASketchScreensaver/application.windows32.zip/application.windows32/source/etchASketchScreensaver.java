import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class etchASketchScreensaver extends PApplet {

// Global Variable
float x, y;
int xpos, ypos, wdth, ht, xspeed, yspeed;
PFont font;

public void setup() {
  
  x = 0;
  y = 0;
  xpos = width/2;
  ypos = height/2;
  wdth = 100;
  ht = 100;
  xspeed = 100;
  yspeed = 30;
  font = loadFont("AppleSDGothicNeo-UltraLight-50.vlw");
}

public void draw() {
  background(0);
  noCursor();
  frameRate(1);
  int c = color(random(255), random(255), random(255));

  // Name
  x = random(width - 450);
  y = random((height * 0.7f) - 200);
  strokeWeight(random(1, 12));
  stroke(c);
  drawName();

  // Clock
  int h = hour();
  int mi = minute();
  fill(c);
  textFont(font);
  textSize(80);
  if (mi<10) {
    text(h + ":" + "0" + mi, width * 0.8f, height * 0.8f);
  } else {
    text(h + ":" + mi, width * 0.8f, height * 0.8f);
  }

  // Shapes
  ellipse(xpos, ypos, wdth, ht);
  xpos += xspeed;
  ypos += yspeed;
  if (xpos >= width - wdth/2 || xpos <= wdth/2) {
    xspeed *= -1;
  }
  if (ypos >= (height * 0.7f) - ht/2 || ypos <= ht/2) {
    yspeed *= -1;
  }
}

// Algorithm for your first name
public void drawName() {
  moveRight(50);
  moveDown(150);
  moveLeft(50);
  moveUp(50);
  moveDown(50);
  moveRight(60);
  moveUp(75);
  moveRight(50);
  moveDown(75);
  moveLeft(50);
  moveRight(60);
  moveUp(75);
  moveRight(50);
  moveDown(75);
  moveRight(10);
  moveUp(75);
  moveRight(40);
  moveDown(75);
  moveLeft(40);
  moveRight(40);
  moveUp(10);
  moveRightDown(10);
  moveRight(10);
  moveRight(25);
  moveUp(150);
  moveDown(60);
  moveLeft(25);
  moveRight(50);
  moveLeft(25);
  moveDown(90);
  moveRight(35);
  moveUp(150);
  moveDown(75);
  moveRight(50);
  moveDown(75);
  moveRight(10);
  moveUp(75);
  moveRight(40);
  moveDown(75);
  moveLeft(40);
  moveRight(40);
  moveUp(10);
  moveRightDown(10);
  moveRight(10);
  moveUp(75);
  moveRight(50);
  moveDown(75);
  moveRight(10);
}

//Method to draw left line
public void moveLeft (int rep) {
  for (int i = 0; i < rep; i++) {
    point(x - i, y);
  }
  x = x - rep;
}

// Method to draw right line
public void moveRight(int rep) {
  for (int i = 0; i < rep; i++) {
    point(x + i, y);
  }
  x = x + rep;
}

//Method to draw lines up
public void moveUp (int rep) {
  for (int i = 0; i < rep; i++) {
    point(x, y - i);
  }
  y = y - rep;
}

//Method to draw lines down
public void moveDown (int rep) {
  for (int i = 0; i < rep; i++) {
    point(x, y + i);
  }
  y = y + rep;
}

//Method to draw lines right and up
public void moveRightUp (int rep) {
  for (int i = 0; i < rep; i++) {
    point(x+i, y-i);
  }
  x = x + rep;
  y = y - rep;
}

//Method to draw lines right and down
public void moveRightDown (int rep) {
  for (int i = 0; i < rep; i++) {
    point(x+i, y+i);
  }
  x = x + rep;
  y = y + rep;
}
  public void settings() {  size(displayWidth, displayHeight); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "etchASketchScreensaver" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
