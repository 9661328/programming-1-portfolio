import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGame extends PApplet {

// SpaceGame | Dec. 2020
// by Jonathan Su


SoundFile fire, fireNo, end, shatter, denied, kaching, reload, repair;
Spaceship s1;
EnemyShip f2;
Timer asteroidTimer, pUpTimer;
ArrayList<Projectile> projectiles;
ArrayList<Asteroid> asteroids;
ArrayList<Star> stars;
ArrayList<PowerUp> powerups;
Car[] cars = new Car[5];
int pass;
boolean play;
PImage background, gameOver;
PFont startFont, panelFont;

public void setup() {
  
  fire = new SoundFile(this, "RPG.wav");
  fireNo = new SoundFile(this, "Nope Sound Effect.wav");
  end = new SoundFile(this, "end.mp3");
  shatter = new SoundFile(this, "Window Break.wav");
  denied = new SoundFile(this, "Denied.wav");
  kaching = new SoundFile(this, "kaching.wav");
  reload = new SoundFile(this, "reload.mp3");
  repair = new SoundFile(this, "repair.mp3");
  s1 = new Spaceship(0xffDBFCEE);
  f2 = new EnemyShip(0xffF4FC12);
  asteroidTimer = new Timer(1000);
  asteroidTimer.start();
  pUpTimer = new Timer(8000);
  pUpTimer.start();
  projectiles = new ArrayList();
  asteroids = new ArrayList();
  stars = new ArrayList();
  powerups = new ArrayList();
  pass = 0;
  play = false;
  for (int i = 0; i < cars.length; i++) {
    cars[i] = new Car(color(random(255), random(255), random(255)), random(20, 50));
  }
  background = loadImage("planets.jpeg");
  gameOver = loadImage("gameOver.jpg");
  panelFont = loadFont("Cochin-15.vlw");
  startFont = loadFont("DINCondensed-Bold-15.vlw");
}

public void draw() {
  if (!play) {
    startScreen();
  } else {
    background(0);
    noCursor();
    image(background, 0, 5, 900, 495);
    stars.add(new Star(PApplet.parseInt(random(width)), (PApplet.parseInt(random(height)))));
    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.move();
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }
    for (int i = 0; i < projectiles.size(); i++) {
      Projectile projectile = projectiles.get(i);
      projectile.display();
      projectile.fire();
      // If projectile hits a rock
      for (int e = 0; e < asteroids.size(); e++) {
        Asteroid asteroid = asteroids.get(e);
        if (asteroid.projectileIntersection(projectile)) {
          asteroids.remove(asteroid);
          s1.score += random(100);
          denied.play();
          projectile.c = color(0, 255, 0);
        }
      }
      if (projectile.reachedTop()) {
        for (int p = 0; p < asteroids.size(); p++) {
          Asteroid asteroid = asteroids.get(p);
          if (asteroid.projectileIntersection(projectile) == false) {
            fireNo.play();
          }
        }
        projectiles.remove(projectile);
      }
    }
    if (asteroidTimer.isFinished()) {
      asteroids.add(new Asteroid(PApplet.parseInt(random(width)), -20));
    }
    for (int i = 0; i < asteroids.size(); i++) {
      Asteroid asteroid = asteroids.get(i);
      asteroid.display();
      asteroid.move();
      // Asteroid + ship collision
      if (s1.rockIntersection(asteroid)) {
        s1.health -= asteroid.health;
        fill(255, 0, 0);
        textAlign(CENTER);
        s1.warning = "Warning: You may have hit a big rock or SpaceBird! \nClick F to pay respects.";
        shatter.play();
        asteroids.remove(asteroid);
      }
      if (asteroid.reachedBottom()) {
        pass++;
        s1.score -= random(500);
        asteroids.remove(asteroid);
        fireNo.play();
      }
      asteroidTimer.start();
    }
    if (pUpTimer.isFinished()) {
      powerups.add(new PowerUp(PApplet.parseInt(random(width)), -20));
      pUpTimer.start();
    }
    for (int i = 0; i < powerups.size(); i++) {
      PowerUp pu = powerups.get(i);
      pu.display();
      pu.move();
      // Ship + powerup collision
      if (s1.puIntersection(pu)) {
        kaching.play();
        if (pu.pu == 0) {
          s1.ammo += 5;
          s1.score += random(100);
          reload.play();
        } else if (pu.pu == 1) {
          s1.health += 50;
          s1.score += random(100);
          repair.play();
        }
        powerups.remove(pu);
      }
      if (pu.reachedBottom()) {
        powerups.remove(pu);
      }
    }
    for (int i = 0; i < cars.length; i++) {
      cars[i].display();
      cars[i].drive();
    }
    s1.display(mouseX, mouseY);
    f2.display(mouseY, mouseX);
    infoPanel();

    // When to end the game
    if (s1.health < 1) {
      s1.lives --; 
      s1.health = PApplet.parseInt(random(200));
      if (s1.lives < 1 || pass > 50) {
        play = false;
        endScreen();
      }
    }
  }
}

public void mousePressed() {
  if (s1.ammo > 0 && play) {
    fire.play();
    projectiles.add(new Projectile(s1.x, s1.y));
    projectiles.add(new Projectile(f2.x, f2.y));
    s1.ammo --;
    s1.health -= 5;
  }
}

public void keyPressed() {
  if (key == 'f' || key == 'F') {
    s1.warning = "";
    s1.score += 500;
  }
}

public void infoPanel() {
  rectMode(CORNER);
  fill(130, 130);
  stroke(255, 255, 0);
  rect(width * 0.75f, height * 0.05f, 110, 110);
  textAlign(LEFT);
  textSize(15);
  textFont(panelFont);

  if (s1.isOut()) {
    fill(255, 0, 0);
  } else {
    fill(0, 255, 0);
  }
  text("Ammo: " + s1.ammo, width * 0.77f, height * 0.2f);

  if (s1.health < 50) {
    fill(255, 0, 0);
  } else {
    fill(255);
  }
  text("Health: " + s1.health, width * 0.77f, height * 0.1f);

  if (s1.lives == 3) {
    fill(0, 0, 255);
  } else if (s1.lives == 2) {
    fill(255, 255, 0);
  } else if (s1.lives == 1) {
    fill(255, 0, 0);
  }
  text("Lives: " + s1.lives, width * 0.77f, height * 0.15f);

  fill(255);
  text("Score: " + s1.score, width * 0.77f, height * 0.25f);
}

public void startScreen() {
  background(0);
  textAlign(CENTER, CENTER);
  textFont(startFont);
  text("Welcome to SpaceGame beta!", width/2, height/2);
  text("Click to Continue: ", width/2, height/2 + 40);

  if (mousePressed) {
    play = true;
  }
}

public void endScreen() {
  noLoop();
  image(gameOver, 0, 0, 500, 500);
  textAlign(CENTER);
  text("Final score: " + s1.score, width * 0.5f, height * 0.85f);
  end.play();
}
class Asteroid {
  // Member variables
  int x, y, health, speed, radius;
  int c;
  char displayMode;

  // Constructor 
  Asteroid(int x, int y) {
    this.x = x;
    this.y = y;
    health = 50;
    speed = PApplet.parseInt(random(5, 30));
    radius = 20;
    c = color(random(180), random(180), random(180));
  }

  // Member methods
  public void display() {
    fill(c);
    noStroke();
    ellipse(x, y, 50, 50);
    fill(0);
  }

  public void move() {
    y += speed;
  }

  public boolean projectileIntersection(Projectile projectile) {
    float distance = dist(x, y, projectile.x, projectile.y);
    if (distance < radius + projectile.wide) {
      return true;
    } else {
      return false;
    }
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
}
class Car {
  //Member variables
  int c;
  float xpos, ypos, xspeed, radius;
  boolean wrongWay;

  //Constructor
  Car(int c, float xspeed) {
    this.c = c;
    xpos = random(width);
    ypos = random(height);
    this.xspeed = xspeed;
    radius = 5;
    if (random(100) > 50) {
      wrongWay = true;
    } else {
      wrongWay = false;
    }
  }

  //Member methods
  public void display() {
    rectMode(CENTER);
    stroke(0);
    fill(c);
    rect(xpos, ypos, 20, 10, 5);
    fill(0);
    rect(xpos-3, ypos-7, 3, 5);
    rect(xpos-3, ypos+7, 3, 5);
    rect(xpos+3, ypos-7, 3, 5);
    rect(xpos+3, ypos+7, 3, 5);
    fill(255, 255, 0);
    noStroke();
    //triangle(xpos+15, ypos, xpos+25, ypos-10, xpos+25, ypos+10);
  }
  public void drive() {
    if (wrongWay) {
      xpos -= xspeed;
      if (xpos < 0) {
        xpos = width;
      }
    } else {
      xpos += xspeed;
      if (xpos > width) {
        xpos = 0;
      }
    }
  }
  
  public boolean shipIntersect(Spaceship s1) {
    float distance = dist(xpos, ypos, s1.x, s1.y);
    if (distance < radius + s1.radius) {
      return true;
    } else {
      return false;
    }
  }
}
class EnemyShip {
  // Member variables
  int x, y, health, ammo, lives, radius, speed;
  char displayMode;
  int c1;
  String warning;

  // Constructor
  EnemyShip(int c1) {
    x = 0;
    y = 0;
    health = 500;
    ammo = 5;
    lives = 3;
    radius = 40;
    speed = 8;
    displayMode = '1';
    this.c1 = c1;
    warning = "";
  }

  // Member methods
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    if (displayMode == '1') {
      stroke(0);
      strokeWeight(1);
      rectMode(CENTER);
      fill(c1);
      rect(x, y, 50, 80, 10);
      triangle(x-24, y-35, x, y-60, x+24, y-35);
      //fill(c1);
      ellipse(x, y-15, 20, 20);
      fill(230);
      ellipse(x, y-20, 18, 8);
      fill(c1);
      quad(x, y+20, x-10, y+30, x, y+60, x+10, y+30);
      quad(x-25, y+20, x-40, y+35, x-20, y+60, x-25, y+40);
      quad(x+25, y+20, x+40, y+35, x+20, y+60, x+25, y+40);
      strokeWeight(3);
      stroke(255, 255, 0);
      line(x-22, y+10, x+22, y+10);
      textAlign(CENTER);
      textSize(6);
      fill(0xff3647FC);
      text("SpaceX", x, y-40);
      textSize(15);
      fill(255, 0, 0);
      text(warning, width/2, height * 0.9f);
    }
  }
}
class PowerUp {
  // Member variables
  int x, y, speed, radius, pu;
  String[] puInfo = {"Ammo", "Health"};

  // Constructor 
  PowerUp(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1, 10));
    radius = 10;
    pu = PApplet.parseInt(random(2));
  }

  // Member methods
  public void display() {
    switch(pu) {
    case 0: //Ammo
      fill(255, 0, 0);
      ellipse(x, y, radius, radius);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[0], x, y);
      break;
    case 1: //Health
      fill(255, 0, 0);
      ellipse(x, y, radius, radius);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[1], x, y);
      break;
    }
  }

  public void move() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
}
class Projectile {
  // Member variables
  int x, y, speed, wide;
  int c;

  // Constructor 
  Projectile(int x, int y) {
    this.x = x;
    this.y = y;
    speed = 30;
    wide = 10;
    c = 180;
  }

  // Member methods
  public void display() {
    fill(c);
    noStroke();
    rectMode(CENTER);
    rect(x, y, wide, 120);
  }

  public void fire() {
    y -= speed;
  }

  public boolean reachedTop() {
    if (y < 0) {
      return true;
    } else {
      return false;
    }
  }
}
class Spaceship {
  // Member variables
  int x, y, health, ammo, lives, radius, score;
  char displayMode;
  int c1;
  String warning;

  // Constructor
  Spaceship(int c1) {
    x = 0;
    y = 0;
    health = PApplet.parseInt(random(500));
    ammo = 5;
    lives = 3;
    radius = 40;
    score = 0;
    displayMode = '1';
    this.c1 = c1;
    warning = "";
  }

  // Member methods
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    if (displayMode == '1') {
      stroke(0);
      strokeWeight(1);
      rectMode(CENTER);
      fill(c1);
      rect(x, y, 50, 80, 10);
      triangle(x-24, y-35, x, y-60, x+24, y-35);
      //fill(c1);
      ellipse(x, y-15, 20, 20);
      fill(230);
      ellipse(x, y-20, 18, 8);
      fill(c1);
      quad(x, y+20, x-10, y+30, x, y+60, x+10, y+30);
      quad(x-25, y+20, x-40, y+35, x-20, y+60, x-25, y+40);
      quad(x+25, y+20, x+40, y+35, x+20, y+60, x+25, y+40);
      strokeWeight(3);
      stroke(255, 255, 0);
      line(x-22, y+10, x+22, y+10);
      textAlign(CENTER);
      textSize(6);
      fill(0xff3647FC);
      text("NASA", x, y-40);
      textSize(15);
      fill(255, 0, 0);
      text(warning, width/2, height * 0.9f);
    }
  }

  public boolean rockIntersection(Asteroid asteroid) {
    float distance = dist(x, y, asteroid.x, asteroid.y);
    if (distance < radius + asteroid.radius) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean puIntersection(PowerUp powerup) {
    float distance = dist(x, y, powerup.x, powerup.y);
    if (distance < radius + powerup.radius) {
      return true;
    } else {
      return false;
    }
  }

  public boolean isOut() {
    if (ammo < 1) {
      return true;
    } else {
      return false;
    }
  }
}
class Star {
  // Member variables
  int x, y, speed, diameter;
  int c;

  // Constructor 
  Star(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1, 5));
    diameter = PApplet.parseInt(random(5));
    c = 255;
  }

  // Member methods
  public void display() {
    fill(c);
    noStroke();
    ellipse(x, y, diameter, diameter);
  }

  public void move() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
}
// Object-oriented timer
// by Daniel Shiffman

class Timer {
  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() {
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
